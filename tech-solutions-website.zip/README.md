# Tech Solutions - Professional IT Services Website

A modern, responsive business website for Tech Solutions, an IT services company based in Ghaziabad, Delhi NCR.

## 🌟 Features

### Pages
- **Home** - Hero section, services overview, company preview, client showcase, CTA
- **About** - Company history, mission, vision, values, team, timeline
- **Services** - Detailed service descriptions (8+ services)
- **Products** - Product categories and authorized brands
- **Clients** - Client testimonials and logo showcase
- **Careers** - Job openings and application form
- **Contact** - Contact form with Google Maps integration

### Key Features
- 📱 Fully Responsive Design (Mobile, Tablet, Desktop)
- 🎨 Modern Pink-Purple Gradient Theme
- ✨ Glassmorphism Header with Sticky Navigation
- 🎭 Smooth Animations with Framer Motion
- 💬 Live Chat Widget
- 📞 Floating WhatsApp & Call Buttons
- 🗺️ Google Maps Integration
- 📊 Client Testimonials Slider
- 🔄 Client Logo Marquee

## 🛠️ Tech Stack

### Frontend
- **React** 18.x
- **React Router DOM** - Multi-page navigation
- **Tailwind CSS** - Styling
- **Framer Motion** - Animations
- **Lucide React** - Icons
- **React Fast Marquee** - Client logos slider
- **Swiper** - Testimonials slider
- **Axios** - API calls

### Backend
- **FastAPI** - Python web framework
- **Motor** - Async MongoDB driver
- **Pydantic** - Data validation
- **Python Dotenv** - Environment variables

### Database
- **MongoDB** - NoSQL database

## 📦 Installation

### Prerequisites
- Node.js (v16 or higher)
- Python 3.11+
- MongoDB

### Backend Setup

1. Navigate to backend directory:
```bash
cd backend
```

2. Create virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Configure environment variables in `.env`:
```
MONGO_URL=mongodb://localhost:27017
DB_NAME=tech_solutions
CORS_ORIGINS=*
```

5. Start the backend server:
```bash
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

### Frontend Setup

1. Navigate to frontend directory:
```bash
cd frontend
```

2. Install dependencies:
```bash
yarn install
# or
npm install
```

3. Configure environment variables in `.env`:
```
REACT_APP_BACKEND_URL=http://localhost:8001
```

4. Start the development server:
```bash
yarn start
# or
npm start
```

The website will be available at `http://localhost:3000`

## 🔌 API Endpoints

### Contact Form
- `POST /api/contact` - Submit contact inquiry
- `GET /api/contact` - Get all contact submissions

### Testimonials
- `POST /api/testimonials` - Add testimonial
- `GET /api/testimonials` - Get all testimonials

### Blog
- `POST /api/blog` - Create blog post
- `GET /api/blog` - Get all blog posts
- `GET /api/blog/{slug}` - Get single blog post

### Careers
- `POST /api/careers` - Submit job application
- `GET /api/careers` - Get all applications

## 🎨 Design System

### Colors
- **Primary Gradient**: Pink (#EC4899) to Purple (#9333EA)
- **Secondary**: Dark Navy (#0F172A)
- **Background**: White (#FFFFFF) / Light Gray (#F8FAFC)
- **Text**: Slate-900 (#0F172A) / Slate-600 (#475569)

### Typography
- **Headings**: Outfit (Bold, 600-700 weight)
- **Body**: Manrope (Regular, 400-500 weight)

### Components
- Glassmorphism header with backdrop blur
- Rounded cards with hover lift effects
- Gradient buttons with shadow effects
- Modern service cards with icons

## 📱 Responsive Breakpoints
- Mobile: < 768px
- Tablet: 768px - 1024px
- Desktop: > 1024px

## 🚀 Deployment

### Frontend
Build for production:
```bash
cd frontend
yarn build
```

Deploy the `build` folder to any static hosting service (Vercel, Netlify, etc.)

### Backend
Deploy FastAPI backend to:
- Railway
- Render
- Heroku
- DigitalOcean
- AWS

Ensure MongoDB is accessible from your deployment environment.

## 📧 Contact Information

**Tech Solutions**
- 📍 Address: Ghaziabad, Delhi NCR, India - 201001
- 📞 Phone: +91 99999 99999
- 📧 Email: info@techsolutions.com
- 🌐 Website: [Tech Solutions](https://techsolutions.com)

## 📄 License

© 2024 Tech Solutions. All rights reserved.

## 🤝 Support

For support and inquiries, please contact us through the website or email info@techsolutions.com

---

**Built with ❤️ by Emergent AI**
