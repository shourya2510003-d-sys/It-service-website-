import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Server, 
  Shield, 
  Network, 
  HardDrive, 
  Code, 
  Database, 
  ShoppingCart, 
  Wrench,
  Clock,
  Users,
  Zap,
  Award,
  DollarSign,
  ArrowRight,
  CheckCircle
} from 'lucide-react';
import Marquee from 'react-fast-marquee';

const Home = () => {
  const services = [
    {
      icon: <Server size={32} className="text-purple-600" />,
      title: 'Annual Maintenance Contracts',
      description: 'Comprehensive AMC services for all your IT infrastructure with 24/7 support.',
      image: 'https://static.prod-images.emergentagent.com/jobs/50c240b7-394d-4ba3-9961-a222b33bb1ea/images/60cf7f1cccc6e079dd534fd75461ba0bb57bdb44bcf6c5975ebacfbf0c3e6167.png'
    },
    {
      icon: <HardDrive size={32} className="text-purple-600" />,
      title: 'Computer Hardware Solutions',
      description: 'Premium quality hardware solutions from leading brands for your business needs.',
      image: 'https://static.prod-images.emergentagent.com/jobs/50c240b7-394d-4ba3-9961-a222b33bb1ea/images/60cf7f1cccc6e079dd534fd75461ba0bb57bdb44bcf6c5975ebacfbf0c3e6167.png'
    },
    {
      icon: <Network size={32} className="text-purple-600" />,
      title: 'Networking Solutions',
      description: 'Advanced networking infrastructure setup and management for seamless connectivity.',
      image: 'https://static.prod-images.emergentagent.com/jobs/50c240b7-394d-4ba3-9961-a222b33bb1ea/images/43c0b50a1e93777427921f634c24412582c2201478a858a08e68f3198bccf9b2.png'
    },
    {
      icon: <Shield size={32} className="text-purple-600" />,
      title: 'IT Security Solutions',
      description: 'Robust security systems to protect your business from cyber threats.',
      image: 'https://static.prod-images.emergentagent.com/jobs/50c240b7-394d-4ba3-9961-a222b33bb1ea/images/2c53bfc85e847ab01bae72d5c2c2156c3aba9b5493967c1138086eee689e48ea.png'
    },
    {
      icon: <Code size={32} className="text-purple-600" />,
      title: 'Software Services',
      description: 'Custom software solutions and enterprise application support.',
      image: 'https://images.unsplash.com/photo-1746470427657-eb0b0115455f?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1ODR8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMGRhdGElMjBuZXR3b3JrJTIwYmx1ZSUyMHB1cnBsZXxlbnwwfHx8fDE3NzQ5NTczMjN8MA&ixlib=rb-4.1.0&q=85'
    },
    {
      icon: <Database size={32} className="text-purple-600" />,
      title: 'Data Backup & Recovery',
      description: 'Reliable data backup solutions to ensure business continuity.',
      image: 'https://images.unsplash.com/photo-1746470427657-eb0b0115455f?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1ODR8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMGRhdGElMjBuZXR3b3JrJTIwYmx1ZSUyMHB1cnBsZXxlbnwwfHx8fDE3NzQ5NTczMjN8MA&ixlib=rb-4.1.0&q=85'
    },
    {
      icon: <ShoppingCart size={32} className="text-purple-600" />,
      title: 'Product Sales',
      description: 'Authorized dealer for top IT brands and technology products.',
      image: 'https://static.prod-images.emergentagent.com/jobs/50c240b7-394d-4ba3-9961-a222b33bb1ea/images/60cf7f1cccc6e079dd534fd75461ba0bb57bdb44bcf6c5975ebacfbf0c3e6167.png'
    },
    {
      icon: <Wrench size={32} className="text-purple-600" />,
      title: 'Printer & Laptop Repair',
      description: 'Expert repair services for laptops, printers, and peripherals.',
      image: 'https://static.prod-images.emergentagent.com/jobs/50c240b7-394d-4ba3-9961-a222b33bb1ea/images/60cf7f1cccc6e079dd534fd75461ba0bb57bdb44bcf6c5975ebacfbf0c3e6167.png'
    }
  ];

  const features = [
    {
      icon: <Clock size={40} className="text-purple-600" />,
      title: '24/7 Support',
      description: 'Round-the-clock technical support for your business needs'
    },
    {
      icon: <Award size={40} className="text-purple-600" />,
      title: 'Certified Engineers',
      description: 'Highly qualified and certified IT professionals'
    },
    {
      icon: <Zap size={40} className="text-purple-600" />,
      title: 'Fast Response',
      description: 'Quick turnaround time for all service requests'
    },
    {
      icon: <CheckCircle size={40} className="text-purple-600" />,
      title: 'Reliable Service',
      description: 'Proven track record of excellence since 2018'
    },
    {
      icon: <DollarSign size={40} className="text-purple-600" />,
      title: 'Affordable Pricing',
      description: 'Competitive pricing without compromising quality'
    },
    {
      icon: <Users size={40} className="text-purple-600" />,
      title: 'Trusted by Businesses',
      description: 'Serving 100+ satisfied clients across India'
    }
  ];

  const values = [
    'Ethical Practices',
    'Commitment to Deadlines',
    'Respect for Customers',
    'Excellence through Teamwork',
    'Passion at Work'
  ];

  const clientLogos = [
    'https://images.unsplash.com/photo-1746047420047-03fc7a9b9226?w=200',
    'https://images.pexels.com/photos/15863044/pexels-photo-15863044.jpeg?w=200',
    'https://images.unsplash.com/photo-1746047420047-03fc7a9b9226?w=200',
    'https://images.pexels.com/photos/15863044/pexels-photo-15863044.jpeg?w=200',
    'https://images.unsplash.com/photo-1746047420047-03fc7a9b9226?w=200'
  ];

  return (
    <div className="min-h-screen" data-testid="home-page">
      {/* Hero Section */}
      <section 
        className="relative min-h-screen flex items-center pt-20"
        style={{
          backgroundImage: `linear-gradient(rgba(15, 23, 42, 0.7), rgba(15, 23, 42, 0.7)), url('https://static.prod-images.emergentagent.com/jobs/50c240b7-394d-4ba3-9961-a222b33bb1ea/images/b5c9d52f1de2f15ae5ca040722cd6175b8530e653074848d1e7eb11fdbbf1e4a.png')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
        data-testid="hero-section"
      >
        <div className="max-w-7xl mx-auto px-6 md:px-12 py-20 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 tracking-tight leading-tight">
              Empowering Businesses<br />
              <span className="gradient-text bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
                Through Technology
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-slate-300 mb-10 max-w-3xl mx-auto">
              Reliable IT solutions for your business growth. Since 2018.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
              <Link to="/contact" className="btn-primary flex items-center space-x-2" data-testid="hero-contact-button">
                <span>Contact Us</span>
                <ArrowRight size={20} />
              </Link>
              <Link to="/services" className="btn-outline bg-white hover:bg-purple-50" data-testid="hero-services-button">
                Get Free Consultation
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-24 md:py-32 bg-white" data-testid="services-section">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-xs md:text-sm font-bold tracking-[0.2em] uppercase text-purple-600 mb-4">
              Our Services
            </h2>
            <h3 className="text-3xl md:text-4xl lg:text-5xl font-bold text-slate-900 mb-4 tracking-tight">
              Complete IT Solutions
            </h3>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              From hardware to software, we provide comprehensive technology solutions for your business
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="service-card hover-lift"
                data-testid={`service-card-${index}`}
              >
                <div className="mb-4">{service.icon}</div>
                <h4 className="text-xl font-semibold text-slate-900 mb-3">{service.title}</h4>
                <p className="text-slate-600 text-sm leading-relaxed">{service.description}</p>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link to="/services" className="btn-primary inline-flex items-center space-x-2" data-testid="view-all-services-button">
              <span>View All Services</span>
              <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* About Preview Section */}
      <section className="py-24 md:py-32 bg-slate-50" data-testid="about-preview-section">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-xs md:text-sm font-bold tracking-[0.2em] uppercase text-purple-600 mb-4">
                About Tech Solutions
              </h2>
              <h3 className="text-3xl md:text-4xl lg:text-5xl font-bold text-slate-900 mb-6 tracking-tight">
                7+ Years of Excellence
              </h3>
              <p className="text-lg text-slate-600 mb-6 leading-relaxed">
                Since 2018, Tech Solutions has been at the forefront of providing state-of-the-art technological solutions for businesses across India. We act as a one-stop IT partner for organizations of all sizes.
              </p>
              <div className="mb-8">
                <h4 className="text-xl font-semibold text-slate-900 mb-4">Our Values</h4>
                <div className="space-y-3">
                  {values.map((value, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <CheckCircle size={20} className="text-purple-600 flex-shrink-0" />
                      <span className="text-slate-700">{value}</span>
                    </div>
                  ))}
                </div>
              </div>
              <Link to="/about" className="btn-primary inline-flex items-center space-x-2" data-testid="learn-more-button">
                <span>Learn More About Us</span>
                <ArrowRight size={18} />
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <img
                src="https://static.prod-images.emergentagent.com/jobs/50c240b7-394d-4ba3-9961-a222b33bb1ea/images/6e53a02d038763f4acc322eb9ac833853322940c9f98c435f5e8bfd16c83c6f8.png"
                alt="About Tech Solutions"
                className="rounded-2xl shadow-2xl w-full"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-24 md:py-32 bg-white" data-testid="why-choose-us-section">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-xs md:text-sm font-bold tracking-[0.2em] uppercase text-purple-600 mb-4">
              Why Choose Us
            </h2>
            <h3 className="text-3xl md:text-4xl lg:text-5xl font-bold text-slate-900 mb-4 tracking-tight">
              Your Trusted IT Partner
            </h3>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white border border-slate-200 rounded-2xl p-8 hover-lift"
                data-testid={`feature-card-${index}`}
              >
                <div className="mb-4">{feature.icon}</div>
                <h4 className="text-xl font-semibold text-slate-900 mb-3">{feature.title}</h4>
                <p className="text-slate-600 leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Clients Section */}
      <section className="py-24 md:py-32 bg-slate-50" data-testid="clients-section">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-xs md:text-sm font-bold tracking-[0.2em] uppercase text-purple-600 mb-4">
              Our Clients
            </h2>
            <h3 className="text-3xl md:text-4xl lg:text-5xl font-bold text-slate-900 mb-4 tracking-tight">
              Trusted by Leading Businesses
            </h3>
          </motion.div>

          <Marquee gradient={false} speed={40} data-testid="client-marquee">
            {clientLogos.map((logo, index) => (
              <div key={index} className="mx-8 grayscale hover:grayscale-0 transition-all">
                <img src={logo} alt={`Client ${index + 1}`} className="h-16 w-auto opacity-60 hover:opacity-100" />
              </div>
            ))}
          </Marquee>

          <div className="text-center mt-12">
            <Link to="/clients" className="btn-outline inline-flex items-center space-x-2" data-testid="view-all-clients-button">
              <span>View All Clients</span>
              <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section 
        className="py-24 md:py-32 relative"
        style={{
          background: 'linear-gradient(135deg, #EC4899 0%, #9333EA 100%)'
        }}
        data-testid="cta-section"
      >
        <div className="max-w-7xl mx-auto px-6 md:px-12 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Ready to Transform Your IT Infrastructure?
            </h2>
            <p className="text-xl text-white/90 mb-10 max-w-2xl mx-auto">
              Get in touch with our experts for a free consultation and discover how we can help your business grow.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
              <Link to="/contact" className="btn-secondary bg-white text-purple-600 hover:bg-slate-50" data-testid="cta-contact-button">
                Contact Us Today
              </Link>
              <a href="tel:+919999999999" className="btn-outline border-white text-white hover:bg-white/10" data-testid="cta-call-button">
                Call Now
              </a>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Home;
