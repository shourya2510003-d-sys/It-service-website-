import React from 'react';
import { motion } from 'framer-motion';
import { Building2, TrendingUp, Users } from 'lucide-react';
import Marquee from 'react-fast-marquee';

const Clients = () => {
  const testimonials = [
    {
      name: 'Rajesh Verma',
      company: 'Verma Industries Ltd.',
      position: 'IT Manager',
      content: 'Tech Solutions has been our IT partner for 3 years. Their AMC services are reliable and their team is always responsive. Highly recommended!',
      rating: 5
    },
    {
      name: 'Priya Singh',
      company: 'Singh Enterprises',
      position: 'Operations Head',
      content: 'Excellent networking solutions and implementation. The team completed our office setup within the promised timeline.',
      rating: 5
    },
    {
      name: 'Amit Kumar',
      company: 'Kumar Tech Solutions',
      position: 'CEO',
      content: 'Professional service and great product quality. We have purchased multiple servers and networking equipment from them.',
      rating: 5
    },
    {
      name: 'Neha Gupta',
      company: 'Gupta Traders',
      position: 'Director',
      content: 'Very satisfied with their security solutions. The CCTV and access control systems are working perfectly.',
      rating: 5
    },
    {
      name: 'Suresh Sharma',
      company: 'Sharma Industries',
      position: 'IT Head',
      content: 'Quick response time and knowledgeable engineers. Their support has minimized our IT downtime significantly.',
      rating: 5
    },
    {
      name: 'Anita Desai',
      company: 'Desai Exports',
      position: 'Manager',
      content: 'Great prices and genuine products. We have been buying laptops and accessories from them for 2 years.',
      rating: 5
    }
  ];

  const clientLogos = [
    { name: 'Client 1', url: 'https://images.unsplash.com/photo-1746047420047-03fc7a9b9226?w=200' },
    { name: 'Client 2', url: 'https://images.pexels.com/photos/15863044/pexels-photo-15863044.jpeg?w=200' },
    { name: 'Client 3', url: 'https://images.unsplash.com/photo-1746047420047-03fc7a9b9226?w=200' },
    { name: 'Client 4', url: 'https://images.pexels.com/photos/15863044/pexels-photo-15863044.jpeg?w=200' },
    { name: 'Client 5', url: 'https://images.unsplash.com/photo-1746047420047-03fc7a9b9226?w=200' },
    { name: 'Client 6', url: 'https://images.pexels.com/photos/15863044/pexels-photo-15863044.jpeg?w=200' }
  ];

  const stats = [
    { icon: <Users size={40} className="text-purple-600" />, number: '100+', label: 'Happy Clients' },
    { icon: <Building2 size={40} className="text-purple-600" />, number: '200+', label: 'Projects Completed' },
    { icon: <TrendingUp size={40} className="text-purple-600" />, number: '7+', label: 'Years of Service' }
  ];

  return (
    <div className="min-h-screen pt-20" data-testid="clients-page">
      {/* Hero */}
      <section className="py-24 md:py-32 bg-gradient-to-br from-purple-50 to-pink-50">
        <div className="max-w-7xl mx-auto px-6 md:px-12 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6 tracking-tight">
              Our <span className="gradient-text">Clients</span>
            </h1>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Trusted by leading businesses across India
            </p>
          </motion.div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-24 md:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-slate-50 rounded-2xl p-10 text-center hover-lift"
                data-testid={`stat-${index}`}
              >
                <div className="flex justify-center mb-4">{stat.icon}</div>
                <h3 className="text-4xl font-bold text-slate-900 mb-2">{stat.number}</h3>
                <p className="text-lg text-slate-600">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Client Logos */}
      <section className="py-24 md:py-32 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Trusted Partners</h2>
            <p className="text-lg text-slate-600">Companies that rely on our IT solutions</p>
          </motion.div>

          <Marquee gradient={false} speed={40} data-testid="client-logo-marquee">
            {clientLogos.map((client, index) => (
              <div key={index} className="mx-8">
                <img
                  src={client.url}
                  alt={client.name}
                  className="h-20 w-auto grayscale hover:grayscale-0 transition-all opacity-60 hover:opacity-100"
                />
              </div>
            ))}
          </Marquee>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 md:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Client Testimonials</h2>
            <p className="text-lg text-slate-600">What our clients say about us</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-slate-50 rounded-2xl p-8 hover-lift"
                data-testid={`testimonial-${index}`}
              >
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <svg
                      key={i}
                      className="w-5 h-5 text-yellow-400 fill-current"
                      viewBox="0 0 20 20"
                    >
                      <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z" />
                    </svg>
                  ))}
                </div>
                <p className="text-slate-700 mb-6 leading-relaxed">"{testimonial.content}"</p>
                <div>
                  <h4 className="font-semibold text-slate-900">{testimonial.name}</h4>
                  <p className="text-sm text-purple-600">{testimonial.position}</p>
                  <p className="text-sm text-slate-500">{testimonial.company}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 md:py-32 gradient-bg">
        <div className="max-w-4xl mx-auto px-6 md:px-12 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Join Our Growing Family
            </h2>
            <p className="text-xl text-white/90 mb-10">
              Become a part of our success story
            </p>
            <a
              href="/contact"
              className="btn-secondary bg-white text-purple-600 hover:bg-slate-50"
              data-testid="clients-contact-button"
            >
              Partner With Us
            </a>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Clients;