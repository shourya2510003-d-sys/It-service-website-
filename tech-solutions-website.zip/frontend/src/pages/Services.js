import React from 'react';
import { motion } from 'framer-motion';
import { Server, Shield, Network, HardDrive, Code, Database, ShoppingCart, Wrench, CheckCircle } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: <Server size={48} className="text-purple-600" />,
      title: 'Annual Maintenance Contracts (AMC)',
      description: 'Comprehensive maintenance services for your entire IT infrastructure',
      features: [
        'Regular preventive maintenance',
        '24/7 technical support',
        'Priority response to issues',
        'Hardware and software coverage',
        'Quarterly performance reviews',
        'Cost-effective long-term plans'
      ],
      image: 'https://static.prod-images.emergentagent.com/jobs/50c240b7-394d-4ba3-9961-a222b33bb1ea/images/60cf7f1cccc6e079dd534fd75461ba0bb57bdb44bcf6c5975ebacfbf0c3e6167.png'
    },
    {
      icon: <HardDrive size={48} className="text-purple-600" />,
      title: 'Computer Hardware Solutions',
      description: 'Premium quality hardware from leading brands for your business',
      features: [
        'Desktop computers and workstations',
        'Laptops and mobile devices',
        'Servers and storage systems',
        'Networking equipment',
        'Peripherals and accessories',
        'Installation and configuration'
      ],
      image: 'https://static.prod-images.emergentagent.com/jobs/50c240b7-394d-4ba3-9961-a222b33bb1ea/images/60cf7f1cccc6e079dd534fd75461ba0bb57bdb44bcf6c5975ebacfbf0c3e6167.png'
    },
    {
      icon: <Network size={48} className="text-purple-600" />,
      title: 'Networking Solutions',
      description: 'Advanced networking infrastructure for seamless connectivity',
      features: [
        'LAN/WAN setup and configuration',
        'Wireless network deployment',
        'Network security implementation',
        'VPN and remote access solutions',
        'Network monitoring and optimization',
        'Structured cabling services'
      ],
      image: 'https://static.prod-images.emergentagent.com/jobs/50c240b7-394d-4ba3-9961-a222b33bb1ea/images/43c0b50a1e93777427921f634c24412582c2201478a858a08e68f3198bccf9b2.png'
    },
    {
      icon: <Shield size={48} className="text-purple-600" />,
      title: 'IT Security Solutions',
      description: 'Robust security systems to protect your business from threats',
      features: [
        'Firewall setup and management',
        'Antivirus and malware protection',
        'Data encryption services',
        'Security audits and assessments',
        'Access control systems',
        'CCTV and surveillance integration'
      ],
      image: 'https://static.prod-images.emergentagent.com/jobs/50c240b7-394d-4ba3-9961-a222b33bb1ea/images/2c53bfc85e847ab01bae72d5c2c2156c3aba9b5493967c1138086eee689e48ea.png'
    },
    {
      icon: <Code size={48} className="text-purple-600" />,
      title: 'Software Services',
      description: 'Custom software solutions and enterprise application support',
      features: [
        'Software installation and licensing',
        'Enterprise application support',
        'Custom software development',
        'Cloud application migration',
        'Software training programs',
        'Version upgrades and patches'
      ],
      image: 'https://images.unsplash.com/photo-1746470427657-eb0b0115455f?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1ODR8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMGRhdGElMjBuZXR3b3JrJTIwYmx1ZSUyMHB1cnBsZXxlbnwwfHx8fDE3NzQ5NTczMjN8MA&ixlib=rb-4.1.0&q=85'
    },
    {
      icon: <Database size={48} className="text-purple-600" />,
      title: 'Data Backup & Recovery',
      description: 'Reliable data backup solutions for business continuity',
      features: [
        'Automated backup systems',
        'Cloud backup solutions',
        'Disaster recovery planning',
        'Data restoration services',
        'Offsite backup management',
        'Compliance and archival solutions'
      ],
      image: 'https://images.unsplash.com/photo-1746470427657-eb0b0115455f?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1ODR8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMGRhdGElMjBuZXR3b3JrJTIwYmx1ZSUyMHB1cnBsZXxlbnwwfHx8fDE3NzQ5NTczMjN8MA&ixlib=rb-4.1.0&q=85'
    },
    {
      icon: <ShoppingCart size={48} className="text-purple-600" />,
      title: 'Product Sales',
      description: 'Authorized dealer for top IT brands and technology products',
      features: [
        'Genuine branded products',
        'Competitive pricing',
        'Warranty and support',
        'Bulk order discounts',
        'Product demonstrations',
        'After-sales service'
      ],
      image: 'https://static.prod-images.emergentagent.com/jobs/50c240b7-394d-4ba3-9961-a222b33bb1ea/images/60cf7f1cccc6e079dd534fd75461ba0bb57bdb44bcf6c5975ebacfbf0c3e6167.png'
    },
    {
      icon: <Wrench size={48} className="text-purple-600" />,
      title: 'Printer & Laptop Repair',
      description: 'Expert repair services for laptops, printers, and peripherals',
      features: [
        'Hardware diagnostics and repair',
        'Screen replacement services',
        'Printer maintenance and repair',
        'Data recovery from damaged devices',
        'Component upgrades',
        'Quick turnaround time'
      ],
      image: 'https://static.prod-images.emergentagent.com/jobs/50c240b7-394d-4ba3-9961-a222b33bb1ea/images/60cf7f1cccc6e079dd534fd75461ba0bb57bdb44bcf6c5975ebacfbf0c3e6167.png'
    }
  ];

  return (
    <div className="min-h-screen pt-20" data-testid="services-page">
      {/* Hero */}
      <section className="py-24 md:py-32 bg-gradient-to-br from-purple-50 to-pink-50">
        <div className="max-w-7xl mx-auto px-6 md:px-12 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6 tracking-tight">
              Our <span className="gradient-text">Services</span>
            </h1>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Comprehensive IT solutions tailored to meet your business needs
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services List */}
      <section className="py-24 md:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-6 md:px-12 space-y-24">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${
                index % 2 === 1 ? 'lg:flex-row-reverse' : ''
              }`}
              data-testid={`service-detail-${index}`}
            >
              <div className={index % 2 === 1 ? 'lg:order-2' : ''}>
                <div className="mb-6">{service.icon}</div>
                <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
                  {service.title}
                </h2>
                <p className="text-lg text-slate-600 mb-6 leading-relaxed">
                  {service.description}
                </p>
                <ul className="space-y-3">
                  {service.features.map((feature, fIndex) => (
                    <li key={fIndex} className="flex items-start space-x-3">
                      <CheckCircle size={20} className="text-purple-600 mt-1 flex-shrink-0" />
                      <span className="text-slate-700">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className={index % 2 === 1 ? 'lg:order-1' : ''}>
                <img
                  src={service.image}
                  alt={service.title}
                  className="rounded-2xl shadow-2xl w-full"
                />
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 md:py-32 gradient-bg">
        <div className="max-w-4xl mx-auto px-6 md:px-12 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Need a Custom Solution?
            </h2>
            <p className="text-xl text-white/90 mb-10">
              Contact us to discuss your specific requirements and get a personalized quote
            </p>
            <a
              href="/contact"
              className="btn-secondary bg-white text-purple-600 hover:bg-slate-50"
              data-testid="services-contact-button"
            >
              Get in Touch
            </a>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Services;