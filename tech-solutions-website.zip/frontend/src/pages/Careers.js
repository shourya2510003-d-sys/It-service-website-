import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Briefcase, Clock, MapPin, Send } from 'lucide-react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const Careers = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    position: '',
    experience: '',
    cover_letter: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitMessage, setSubmitMessage] = useState('');

  const openings = [
    {
      title: 'IT Support Engineer',
      type: 'Full-time',
      location: 'Ghaziabad, Delhi NCR',
      experience: '2-4 years',
      description: 'Provide technical support to clients, troubleshoot hardware and software issues, and maintain IT infrastructure.',
      requirements: [
        'Bachelor\'s degree in Computer Science or related field',
        'Experience with Windows and Linux systems',
        'Strong problem-solving skills',
        'Good communication skills',
        'Certifications like CompTIA A+, Network+ preferred'
      ]
    },
    {
      title: 'Network Administrator',
      type: 'Full-time',
      location: 'Ghaziabad, Delhi NCR',
      experience: '3-5 years',
      description: 'Design, implement, and maintain network infrastructure for clients. Ensure network security and optimal performance.',
      requirements: [
        'Bachelor\'s degree in IT or related field',
        'Experience with Cisco networking equipment',
        'CCNA or CCNP certification',
        'Knowledge of network security',
        'Experience with VPN and firewall configuration'
      ]
    },
    {
      title: 'Sales Executive - IT Products',
      type: 'Full-time',
      location: 'Ghaziabad, Delhi NCR',
      experience: '1-3 years',
      description: 'Drive IT product sales, build client relationships, and achieve sales targets in the B2B segment.',
      requirements: [
        'Bachelor\'s degree in any field',
        'Experience in IT product sales',
        'Excellent communication skills',
        'Client relationship management',
        'Target-oriented mindset'
      ]
    },
    {
      title: 'Field Service Technician',
      type: 'Full-time',
      location: 'Ghaziabad, Delhi NCR',
      experience: '1-2 years',
      description: 'Provide on-site technical support, hardware repairs, and maintenance services to clients.',
      requirements: [
        'Diploma or Bachelor\'s in Computer Science',
        'Hands-on experience with hardware repairs',
        'Willingness to travel',
        'Good troubleshooting skills',
        'Customer service orientation'
      ]
    }
  ];

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitMessage('');

    try {
      await axios.post(`${API}/careers`, formData);
      setSubmitMessage('Thank you for your application! We will review and get back to you soon.');
      setFormData({ name: '', email: '', phone: '', position: '', experience: '', cover_letter: '' });
    } catch (error) {
      setSubmitMessage('Something went wrong. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen pt-20" data-testid="careers-page">
      {/* Hero */}
      <section className="py-24 md:py-32 bg-gradient-to-br from-purple-50 to-pink-50">
        <div className="max-w-7xl mx-auto px-6 md:px-12 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6 tracking-tight">
              Join Our <span className="gradient-text">Team</span>
            </h1>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Build your career with a leading IT solutions provider
            </p>
          </motion.div>
        </div>
      </section>

      {/* Why Work With Us */}
      <section className="py-24 md:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Why Work With Us</h2>
            <p className="text-lg text-slate-600">Great benefits and growth opportunities</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { title: 'Competitive Salary', desc: 'Industry-leading compensation packages' },
              { title: 'Career Growth', desc: 'Regular training and advancement opportunities' },
              { title: 'Work-Life Balance', desc: 'Flexible working hours and leave policies' },
              { title: 'Team Culture', desc: 'Collaborative and supportive work environment' }
            ].map((benefit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-slate-50 rounded-xl p-8 text-center hover-lift"
                data-testid={`benefit-${index}`}
              >
                <h4 className="text-xl font-semibold text-slate-900 mb-3">{benefit.title}</h4>
                <p className="text-slate-600">{benefit.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Current Openings */}
      <section className="py-24 md:py-32 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Current Openings</h2>
            <p className="text-lg text-slate-600">Explore opportunities that match your skills</p>
          </motion.div>

          <div className="space-y-6">
            {openings.map((job, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-8 hover-lift"
                data-testid={`job-opening-${index}`}
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
                  <div>
                    <h3 className="text-2xl font-bold text-slate-900 mb-2">{job.title}</h3>
                    <div className="flex flex-wrap gap-4 text-sm text-slate-600">
                      <span className="flex items-center space-x-1">
                        <Briefcase size={16} />
                        <span>{job.type}</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <MapPin size={16} />
                        <span>{job.location}</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <Clock size={16} />
                        <span>{job.experience}</span>
                      </span>
                    </div>
                  </div>
                </div>
                <p className="text-slate-600 mb-4">{job.description}</p>
                <div>
                  <h4 className="font-semibold text-slate-900 mb-3">Requirements:</h4>
                  <ul className="list-disc list-inside space-y-1 text-slate-600">
                    {job.requirements.map((req, rIndex) => (
                      <li key={rIndex}>{req}</li>
                    ))}
                  </ul>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Application Form */}
      <section className="py-24 md:py-32 bg-white">
        <div className="max-w-4xl mx-auto px-6 md:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Apply Now</h2>
            <p className="text-lg text-slate-600">Submit your application and we'll get back to you</p>
          </motion.div>

          <div className="bg-slate-50 rounded-2xl p-8 md:p-10">
            <form onSubmit={handleSubmit} className="space-y-6" data-testid="career-application-form">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                    data-testid="career-name-input"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-2">
                    Email *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                    data-testid="career-email-input"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-slate-700 mb-2">
                    Phone *
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                    data-testid="career-phone-input"
                  />
                </div>

                <div>
                  <label htmlFor="position" className="block text-sm font-medium text-slate-700 mb-2">
                    Position Applied For *
                  </label>
                  <input
                    type="text"
                    id="position"
                    name="position"
                    value={formData.position}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                    data-testid="career-position-input"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="experience" className="block text-sm font-medium text-slate-700 mb-2">
                  Years of Experience *
                </label>
                <input
                  type="text"
                  id="experience"
                  name="experience"
                  value={formData.experience}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                  data-testid="career-experience-input"
                />
              </div>

              <div>
                <label htmlFor="cover_letter" className="block text-sm font-medium text-slate-700 mb-2">
                  Cover Letter / Additional Information
                </label>
                <textarea
                  id="cover_letter"
                  name="cover_letter"
                  value={formData.cover_letter}
                  onChange={handleChange}
                  rows="6"
                  className="w-full px-4 py-3 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                  data-testid="career-cover-letter-input"
                />
              </div>

              {submitMessage && (
                <div
                  className={`p-4 rounded-xl ${
                    submitMessage.includes('Thank you')
                      ? 'bg-green-100 text-green-800'
                      : 'bg-red-100 text-red-800'
                  }`}
                  data-testid="career-submit-message"
                >
                  {submitMessage}
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="btn-primary w-full flex items-center justify-center space-x-2"
                data-testid="career-submit-button"
              >
                <span>{isSubmitting ? 'Submitting...' : 'Submit Application'}</span>
                <Send size={18} />
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Careers;