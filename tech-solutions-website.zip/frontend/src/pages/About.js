import React from 'react';
import { motion } from 'framer-motion';
import { Target, Eye, Heart, Users, Award, TrendingUp } from 'lucide-react';

const About = () => {
  const timeline = [
    { year: '2018', event: 'Tech Solutions founded in Ghaziabad, Delhi NCR' },
    { year: '2019', event: 'Expanded service offerings to include networking solutions' },
    { year: '2020', event: 'Achieved ISO certification for quality management' },
    { year: '2021', event: 'Crossed 50+ satisfied corporate clients milestone' },
    { year: '2022', event: 'Launched 24/7 support center for enterprise clients' },
    { year: '2023', event: 'Expanded team to 25+ certified IT professionals' },
    { year: '2024', event: 'Celebrating 7 years of excellence and innovation' }
  ];

  const team = [
    {
      name: 'Rajesh Kumar',
      position: 'Founder & CEO',
      image: 'https://images.unsplash.com/photo-1774600134168-b9ebd714e4e1?w=400'
    },
    {
      name: 'Priya Sharma',
      position: 'CTO',
      image: 'https://images.unsplash.com/photo-1774600134168-b9ebd714e4e1?w=400'
    },
    {
      name: 'Amit Patel',
      position: 'Head of Operations',
      image: 'https://images.unsplash.com/photo-1774600134168-b9ebd714e4e1?w=400'
    },
    {
      name: 'Neha Gupta',
      position: 'Client Relations Manager',
      image: 'https://images.unsplash.com/photo-1774600134168-b9ebd714e4e1?w=400'
    }
  ];

  return (
    <div className="min-h-screen pt-20" data-testid="about-page">
      {/* Hero */}
      <section className="py-24 md:py-32 bg-gradient-to-br from-purple-50 to-pink-50" data-testid="about-hero">
        <div className="max-w-7xl mx-auto px-6 md:px-12 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6 tracking-tight">
              About <span className="gradient-text">Tech Solutions</span>
            </h1>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Your trusted technology partner since 2018, delivering excellence in IT solutions across India.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Company Overview */}
      <section className="py-24 md:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <img
                src="https://static.prod-images.emergentagent.com/jobs/50c240b7-394d-4ba3-9961-a222b33bb1ea/images/6e53a02d038763f4acc322eb9ac833853322940c9f98c435f5e8bfd16c83c6f8.png"
                alt="Tech Solutions Office"
                className="rounded-2xl shadow-2xl"
              />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">Who We Are</h2>
              <p className="text-lg text-slate-600 mb-4 leading-relaxed">
                Tech Solutions is a leading IT services company based in Ghaziabad, Delhi NCR. Established in 2018, we have been providing state-of-the-art technological solutions to businesses across India.
              </p>
              <p className="text-lg text-slate-600 mb-4 leading-relaxed">
                We specialize in hardware, networking, security, software, and maintenance services, acting as a one-stop IT partner for organizations of all sizes.
              </p>
              <p className="text-lg text-slate-600 leading-relaxed">
                With a team of certified professionals and a commitment to excellence, we ensure that your technology infrastructure operates at peak performance.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-24 md:py-32 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-white rounded-2xl p-10 shadow-lg hover-lift"
              data-testid="mission-card"
            >
              <Target size={48} className="text-purple-600 mb-6" />
              <h3 className="text-2xl font-bold text-slate-900 mb-4">Our Mission</h3>
              <p className="text-lg text-slate-600 leading-relaxed">
                To be the most reliable IT solution provider delivering dependable technology management and support services across India.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="bg-white rounded-2xl p-10 shadow-lg hover-lift"
              data-testid="vision-card"
            >
              <Eye size={48} className="text-purple-600 mb-6" />
              <h3 className="text-2xl font-bold text-slate-900 mb-4">Our Vision</h3>
              <p className="text-lg text-slate-600 leading-relaxed">
                To empower businesses with cutting-edge technology solutions that drive growth, efficiency, and innovation in the digital age.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-24 md:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Our Core Values</h2>
            <p className="text-lg text-slate-600">The principles that guide everything we do</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {[
              { icon: <Heart size={32} />, title: 'Ethical Practices', desc: 'Integrity in every action' },
              { icon: <Award size={32} />, title: 'Commitment', desc: 'Meeting every deadline' },
              { icon: <Users size={32} />, title: 'Respect', desc: 'Valuing our customers' },
              { icon: <TrendingUp size={32} />, title: 'Excellence', desc: 'Through teamwork' },
              { icon: <Heart size={32} />, title: 'Passion', desc: 'Dedication at work' }
            ].map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-slate-50 rounded-xl p-6 text-center hover-lift"
                data-testid={`value-card-${index}`}
              >
                <div className="text-purple-600 mb-4 flex justify-center">{value.icon}</div>
                <h4 className="text-lg font-semibold text-slate-900 mb-2">{value.title}</h4>
                <p className="text-sm text-slate-600">{value.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-24 md:py-32 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Our Leadership Team</h2>
            <p className="text-lg text-slate-600">Meet the experts driving our success</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl overflow-hidden shadow-lg hover-lift"
                data-testid={`team-member-${index}`}
              >
                <img src={member.image} alt={member.name} className="w-full h-64 object-cover" />
                <div className="p-6 text-center">
                  <h4 className="text-xl font-semibold text-slate-900 mb-2">{member.name}</h4>
                  <p className="text-purple-600 font-medium">{member.position}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-24 md:py-32 bg-white">
        <div className="max-w-5xl mx-auto px-6 md:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Our Journey</h2>
            <p className="text-lg text-slate-600">Milestones that shaped Tech Solutions</p>
          </motion.div>

          <div className="space-y-8">
            {timeline.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="flex items-center space-x-6"
                data-testid={`timeline-item-${index}`}
              >
                <div className="w-24 flex-shrink-0">
                  <span className="text-2xl font-bold text-purple-600">{item.year}</span>
                </div>
                <div className="w-4 h-4 bg-purple-600 rounded-full flex-shrink-0"></div>
                <div className="flex-1 bg-slate-50 rounded-xl p-6">
                  <p className="text-slate-700 text-lg">{item.event}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;