import React from 'react';
import { motion } from 'framer-motion';
import { Package, Cpu, HardDrive, Monitor, Printer, Router, Server, Shield } from 'lucide-react';

const Products = () => {
  const categories = [
    {
      icon: <Cpu size={48} className="text-purple-600" />,
      title: 'Processors & Components',
      products: ['Intel Core i9', 'AMD Ryzen', 'RAM Modules', 'SSDs', 'Graphics Cards']
    },
    {
      icon: <Monitor size={48} className="text-purple-600" />,
      title: 'Desktops & Workstations',
      products: ['Dell OptiPlex', 'HP EliteDesk', 'Lenovo ThinkCentre', 'Custom Built PCs', 'Gaming PCs']
    },
    {
      icon: <HardDrive size={48} className="text-purple-600" />,
      title: 'Laptops',
      products: ['Dell Latitude', 'HP ProBook', 'Lenovo ThinkPad', 'ASUS', 'MacBook']
    },
    {
      icon: <Server size={48} className="text-purple-600" />,
      title: 'Servers & Storage',
      products: ['Dell PowerEdge', 'HP ProLiant', 'NAS Systems', 'SAN Storage', 'Backup Solutions']
    },
    {
      icon: <Router size={48} className="text-purple-600" />,
      title: 'Networking Equipment',
      products: ['Cisco Routers', 'Switches', 'Access Points', 'Firewalls', 'Cables']
    },
    {
      icon: <Printer size={48} className="text-purple-600" />,
      title: 'Printers & Scanners',
      products: ['HP LaserJet', 'Canon ImageCLASS', 'Epson EcoTank', 'Scanners', 'Multi-function']
    },
    {
      icon: <Shield size={48} className="text-purple-600" />,
      title: 'Security Systems',
      products: ['CCTV Cameras', 'Access Control', 'Biometric Systems', 'Security Software', 'Surveillance']
    },
    {
      icon: <Package size={48} className="text-purple-600" />,
      title: 'Peripherals & Accessories',
      products: ['Keyboards', 'Mice', 'Webcams', 'Headsets', 'UPS Systems']
    }
  ];

  const brands = [
    'Dell', 'HP', 'Lenovo', 'Cisco', 'Microsoft', 'Intel', 'AMD', 'ASUS',
    'Canon', 'Epson', 'Seagate', 'Western Digital', 'Samsung', 'Kingston'
  ];

  return (
    <div className="min-h-screen pt-20" data-testid="products-page">
      {/* Hero */}
      <section className="py-24 md:py-32 bg-gradient-to-br from-purple-50 to-pink-50">
        <div className="max-w-7xl mx-auto px-6 md:px-12 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6 tracking-tight">
              Our <span className="gradient-text">Products</span>
            </h1>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Premium quality IT products from leading global brands
            </p>
          </motion.div>
        </div>
      </section>

      {/* Product Categories */}
      <section className="py-24 md:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Product Categories</h2>
            <p className="text-lg text-slate-600">Explore our comprehensive range of IT products</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {categories.map((category, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white border border-slate-200 rounded-2xl p-8 hover-lift"
                data-testid={`product-category-${index}`}
              >
                <div className="mb-6">{category.icon}</div>
                <h3 className="text-xl font-semibold text-slate-900 mb-4">{category.title}</h3>
                <ul className="space-y-2">
                  {category.products.map((product, pIndex) => (
                    <li key={pIndex} className="text-slate-600 text-sm">
                      • {product}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Brands */}
      <section className="py-24 md:py-32 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Authorized Partner</h2>
            <p className="text-lg text-slate-600">We are authorized dealers for leading technology brands</p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-6">
            {brands.map((brand, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 }}
                className="bg-white rounded-xl p-6 flex items-center justify-center hover-lift"
                data-testid={`brand-${index}`}
              >
                <span className="text-slate-700 font-semibold text-center">{brand}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 md:py-32 gradient-bg">
        <div className="max-w-4xl mx-auto px-6 md:px-12 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Need a Product Quote?
            </h2>
            <p className="text-xl text-white/90 mb-10">
              Contact us for competitive pricing and bulk order discounts
            </p>
            <a
              href="/contact"
              className="btn-secondary bg-white text-purple-600 hover:bg-slate-50"
              data-testid="products-contact-button"
            >
              Get a Quote
            </a>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Products;